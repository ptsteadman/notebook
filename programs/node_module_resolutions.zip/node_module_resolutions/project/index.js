const foo = require('../mockGeneratedFile.js')
const jspb = require('google-protobuf')

console.log(jspb)

console.log(`Hello ${foo.bar}!`);
