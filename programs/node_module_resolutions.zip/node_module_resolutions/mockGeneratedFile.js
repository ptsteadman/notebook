// const jspb = require('google-protobuf')

const foo = { bar: 'baz' };
// console.log(jspb)

module.exports = foo;
